import fractions  #导入模块
f=fractions.Fraction(2,4)  #制定分数
print(f) #输出1/2 自动约分